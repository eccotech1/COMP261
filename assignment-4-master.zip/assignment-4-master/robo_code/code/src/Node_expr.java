import java.util.HashMap;
import java.util.Scanner;

public class Node_expr implements Node_Robotexpr {
    public Node_Robotexpr expr = null;
    public static Boolean is_expr = false;
    public static HashMap<String, Integer> map = new HashMap<String, Integer>();
    
    @Override
    public int eval(Robot robot) {
        return expr.eval(robot);
    }
    @Override
    public Node_Robotexpr parse(Scanner s){
        if (s.hasNext(Parser.SENSOR)) {
			expr = new Node_Sensor();
			expr.parse(s);
		}
		else if (s.hasNext(Parser.NUMPAT)) { 
			expr = new Node_Num(); 
			expr.parse(s);
		}
		else if (s.hasNext(Parser.OPERATION)) {
			expr = new Node_opers();
			expr.parse(s);
		}
		else if (s.hasNext(Parser.VARIABLE)) {
		    String variableName = s.next();

		    if (map.containsKey(variableName)) {
		    	expr = new Node_var(variableName);
		    	expr.parse(s);
		    }else {
		    	map.put(variableName, 0);
		    	expr = new Node_var(variableName);
		    	expr.parse(s);
		    }
		}else {
			Parser.fail("Expression Failed\n", s);
		}
		return expr;
    }
    public String toString(){
        return expr.toString();
    }
    
}
