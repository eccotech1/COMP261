import java.util.Scanner;

public class Node_Equal implements Node_RCon{
    public Node_Robotexpr con1 = null;
	public Node_Robotexpr con2 = null;

	@Override
	public boolean eval(Robot robot) {
		if(con1.eval(robot) == con2.eval(robot)){
			return true;
		}
		return false;
	}

	@Override
	public Node_RCon parse(Scanner s) {
		if(!Parser.checkFor(Parser.EQUAL, s)){
			Parser.fail("Node equal Fail\n", s);
		}
		
		if(!Parser.checkFor(Parser.OPENPAREN, s)){
			Parser.fail("Node equal Fail\n", s);
		}
		
		con1 = new Node_expr();
		con1.parse(s);	
		
		if (s.hasNext(Parser.COMMA)) {
			Parser.checkFor(Parser.COMMA, s);
		}
		
		con2 = new Node_expr();
		con2.parse(s);
		
		if (!Parser.checkFor(Parser.CLOSEPAREN, s)) {
			Parser.fail("Node equal Fail\n", s);
		}
		
		return this;
	}
	
	@Override
	public String toString(){
		return "eq("+con1+", "+con2+")";
	}
    
}
