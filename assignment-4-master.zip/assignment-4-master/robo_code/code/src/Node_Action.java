import java.util.Scanner;

public class Node_Action implements RobotProgramNode {
    private RobotProgramNode action = null;
    
    @Override
    public void execute(Robot robot) {
        action.execute(robot);
    }
    @Override
    public RobotProgramNode parse(Scanner s){
        if(s.hasNext(Parser.MOVE)){
            action = new Node_Move();
        }else if(s.hasNext(Parser.TURNL)){
            action = new Node_TakeL();
        }else if(s.hasNext(Parser.TURNR)){
            action = new Node_TurnR();
        }else if(s.hasNext(Parser.TAKEFUEL)){
            action = new Node_TakeFuel();
        }else if(s.hasNext(Parser.WAIT)){
            action = new Node_Wait();
        }else if (s.hasNext(Parser.TURNAROUND)) {
			action = new Node_TurnA();
		}else if (s.hasNext(Parser.SHIELDON)) {
			action = new Node_SOn();
		}else if (s.hasNext(Parser.SHIELDOFF)) {
			action = new Node_SOff();
		}else{
			Parser.fail("ACTNode Fail at", s);
		}
        action.parse(s);
        if (!Parser.checkFor(Parser.SEMICOL, s)) {
			Parser.fail("SemiCol Fail\n", s);
		}
        return action;
    }
    public String toString(){
        return action.toString();
    }
}
