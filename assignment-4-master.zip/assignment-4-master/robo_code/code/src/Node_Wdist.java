import java.util.Scanner;

public class Node_Wdist implements Node_Robotexpr{

	@Override
	public int eval(Robot robot) {
		return robot.getDistanceToWall();
	}

	@Override
	public Node_Robotexpr parse(Scanner s) {
		if(!Parser.checkFor(Parser.WALLDIST, s)){
			Parser.fail("Node WallDist Fail\n", s);
		}
		return this;
	}
	
	public String toString(){
		return Parser.WALLDIST.toString();
	}
}