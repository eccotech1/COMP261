import java.util.Scanner;

public class Node_Sensor implements Node_Robotexpr{
    Node_Robotexpr node = null;

	@Override
	public int eval(Robot robot) {
		return node.eval(robot);
	}

	@Override
	public Node_Robotexpr parse(Scanner s) {
		if (s.hasNext(Parser.FUELLEFT)){
			node = new Node_Fleft();
		} else if (s.hasNext(Parser.OPPLR)){
			node = new Node_OppLr();
		} else if (s.hasNext(Parser.OPPFB)){
			node = new Node_OppFB();
		} else if (s.hasNext(Parser.NUMBARRELS)){
			node = new Node_NumB();
		} else if (s.hasNext(Parser.BARRELLR)){
			node = new Node_BLR();
		} else if (s.hasNext(Parser.BARRELFB)){
			node = new Node_BFB();
		} else if (s.hasNext(Parser.WALLDIST)){
			node = new Node_Wdist();
		}
		node.parse(s);
		return node;
	}
	
	public String toString(){
		return node.toString();
	}
}
