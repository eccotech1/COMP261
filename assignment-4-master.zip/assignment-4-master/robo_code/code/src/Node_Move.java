import java.util.Scanner;

public class Node_Move implements RobotProgramNode {
    
    private Node_expr exprs = null;
    private Node_opers opers = null;
    
    @Override
    public void execute(Robot robot) {
        robot.move();
    }
    
    @Override
    public RobotProgramNode parse(Scanner s) {
        if (!Parser.checkFor(Parser.MOVE, s)) {
            Parser.fail("Failed Move", s);
        }
        if (s.hasNext(Parser.OPENPAREN)) {
            Parser.checkFor(Parser.OPENPAREN, s); 
        }
        
        if (s.hasNext(Parser.NUMPAT) || s.hasNext(Parser.SENSOR)) {
            exprs = new Node_expr();
            exprs.parse(s);
        }
        else if (s.hasNext(Parser.OPERATION)) {
            opers = new Node_opers();
            opers.parse(s);
        }
        
        if (s.hasNext(Parser.CLOSEPAREN)) {
            Parser.checkFor(Parser.CLOSEPAREN, s);
        }
        return this;
    }
    
    public String toString(){
        String s = "move;";
        if(exprs != null){
            return "move("+exprs+")";
        }
        else if(opers  != null){
            return "move("+opers+")";
        }
        else{
            return s;
        }
        
    }
}
    