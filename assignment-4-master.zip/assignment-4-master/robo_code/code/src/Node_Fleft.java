import java.util.Scanner;

public class Node_Fleft implements Node_Robotexpr {

	@Override
	public int eval(Robot robot) {
		return robot.getFuel();
	}

	@Override
	public Node_Robotexpr parse(Scanner s) {
		if(!Parser.checkFor(Parser.FUELLEFT, s)){
			Parser.fail("FuelLeftNode Fail, expected:\n "+Parser.FUELLEFT, s);
		}
		return this;
	}
	
	public String toString() {
		return Parser.FUELLEFT.toString();
	}

}