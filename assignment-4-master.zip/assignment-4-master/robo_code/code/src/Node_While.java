import java.util.Scanner;

public class Node_While implements RobotProgramNode{
    public Node_Con nodeC = null;
	public Node_Block nodeB = null;

	@Override
	public void execute(Robot robot) {
		while(true){
			if(nodeC.eval(robot)){
				nodeB.execute(robot);
			}
			else{
				return;
			}
		}
	}

	@Override
	public RobotProgramNode parse(Scanner s) {
		if (!Parser.checkFor(Parser.WHILE, s)) {
			Parser.fail("Node While\n", s);
		}
		
		if (s.hasNext(Parser.OPENPAREN)) {
			Parser.checkFor(Parser.OPENPAREN, s);
			
			if (s.hasNext(Parser.CONDITION)) {
				nodeC = new Node_Con();
				nodeC.parse(s);
			} else {
				Parser.fail("Node While" + Parser.CONDITION, s);
			}

			if (s.hasNext(Parser.CLOSEPAREN)) {
				Parser.checkFor(Parser.CLOSEPAREN, s);
			}	
			
			nodeB = new Node_Block();
			nodeB.parse(s);
		}
		
		return this;
	}
	
	public String toString(){
		return "while(" + nodeC.toString() + ")" + nodeB.toString();
	}
    
}
