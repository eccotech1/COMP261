import java.util.Scanner;

public class Node_TurnA implements RobotProgramNode {

	@Override
	public void execute(Robot robot) {
		robot.turnAround();		
	}

	@Override
	public RobotProgramNode parse(Scanner s) {
		if (!Parser.checkFor(Parser.TURNAROUND, s)) {
			Parser.fail("Node TurnAround Fail\n", s);
		}
		return this;
	}

	public String toString() {
		return "turnAround;";
	}

}