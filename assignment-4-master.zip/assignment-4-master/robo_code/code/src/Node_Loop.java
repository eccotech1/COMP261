import java.util.Scanner;

public class Node_Loop implements RobotProgramNode {
    RobotProgramNode loop = null;
    /**
     * Add a loop to the program
     */
    @Override
    public void execute(Robot robot) {
        while (true) {
            loop.execute(robot);
        }
    }
    /**
     * Parse a loop
     */
    @Override
    public RobotProgramNode parse(Scanner s) {
        if(!Parser.checkFor(Parser.LOOP, s)){
            Parser.fail("Failed Loop", s);
        }
        loop = new Node_Block();
        loop.parse(s);
        return loop;
    }
    /**
     * toString method for the loop
     */
    public String toString(){
        String s = loop.toString();
        return String.format("loop %s", s);
    }
}
