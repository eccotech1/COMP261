import java.util.Scanner;

public class Node_BFB implements Node_Robotexpr{
	
	Node_Robotexpr node = null;

	@Override
	public int eval(Robot robot) {
		if (node != null) {
			return robot.getBarrelFB(node.eval(robot));
		}
		return robot.getClosestBarrelFB();
	}

	@Override
	public Node_Robotexpr parse(Scanner s) {
		if(!Parser.checkFor(Parser.BARRELFB, s)){
			Parser.fail("Node BarrelFB Fail", s);
		}
		
		if (s.hasNext(Parser.OPENPAREN)) {
			Parser.checkFor(Parser.OPENPAREN, s); 
		}
		
		if (s.hasNext(Parser.SENSOR) || s.hasNext(Parser.NUMPAT) ||
				s.hasNext(Parser.OPERATION) || s.hasNext(Parser.VARIABLE)) {
			node = new Node_expr();
			node.parse(s);
		}
		
		if (s.hasNext(Parser.CLOSEPAREN)) {
			Parser.checkFor(Parser.CLOSEPAREN, s);
		}
			
		return this;
	}
	
	@Override
	public String toString(){
		if (node == null) {
			return "barrelFB;";
		}
		else {
			return "barrelFB("+node+")";
		}
	}
}