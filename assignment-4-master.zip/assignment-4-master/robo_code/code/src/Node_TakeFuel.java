import java.util.Scanner;

public class Node_TakeFuel implements RobotProgramNode{
    @Override
    public void execute(Robot robot) {
        robot.takeFuel();
    }
    @Override
    public RobotProgramNode parse(Scanner s) {
        if(!Parser.checkFor(Parser.TAKEFUEL, s)){
            Parser.fail("Failed Take Fuel\n", s);
        }
        return this;
    }
    public String toString(){
        return "takeFuel;";
    }
}
