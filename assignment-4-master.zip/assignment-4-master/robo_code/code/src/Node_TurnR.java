import java.util.Scanner;

public class Node_TurnR implements RobotProgramNode {
    @Override
    public void execute(Robot robot) {
        robot.turnRight();
    }
    @Override
    public RobotProgramNode parse(Scanner s) {
        if(!Parser.checkFor(Parser.TURNR, s)){
            Parser.fail("Failed Turn Right\n", s);
        }
        return this;
    }
    public String toString() {
        return "turnRight;";
    }
}
    

