import java.util.Scanner;

public class Node_OppLr implements Node_Robotexpr{
	
	@Override
	public int eval(Robot robot) {
		return robot.getOpponentLR();
	}

	@Override
	public Node_Robotexpr parse(Scanner s) {
		if (!Parser.checkFor(Parser.OPPLR, s)) {
			Parser.fail("Node OpponentLR Fail\n", s);
		}
		return this;
	}
	public String toString() {
		return Parser.OPPLR.toString();
	}

}
