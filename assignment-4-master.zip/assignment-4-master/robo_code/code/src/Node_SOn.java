import java.util.Scanner;

public class Node_SOn implements RobotProgramNode {

	@Override
	public void execute(Robot robot) {
		robot.setShield(true);
	}

	@Override
	public RobotProgramNode parse(Scanner s) {
		if(!Parser.checkFor(Parser.SHIELDON, s)){
			Parser.fail("ShieldOn Fail\n", s);
		}
		return this;
	}
	
	public String toString(){
		return "shieldOn;";
	}

}