import java.util.Scanner;

public class Node_Or implements Node_RCon{
    Node_Con nodeA;
    Node_Con nodeB;
    
	@Override
	public boolean eval(Robot robot) {
		return (nodeA.eval(robot) || nodeB.eval(robot));
	}

	@Override
	public Node_RCon parse(Scanner s) {
		if(!Parser.checkFor(Parser.OR, s)){
			Parser.fail("ORNode Fail, expected\n: "+Parser.OR.toString(), s);
		}

		if (!Parser.checkFor(Parser.OPENPAREN, s)) {
			Parser.fail("ORNode - OpenParen Fail, expected:\n" + Parser.OPENPAREN.toString(), s);
		}
		
		nodeA = new Node_Con();
		nodeA.parse(s);
		
		if (s.hasNext(Parser.CLOSEPAREN)) {
			Parser.checkFor(Parser.CLOSEPAREN, s);
		}
		
		if (s.hasNext(Parser.COMMA)) {
			Parser.checkFor(Parser.COMMA, s);
		}

		nodeB = new Node_Con();
		nodeB.parse(s);
		
		if (!Parser.checkFor(Parser.CLOSEPAREN, s)) {
			Parser.fail("ORNode - CloseParen Fail, expected:\n" + Parser.CLOSEPAREN.toString(), s);
		}

		return this;

	}
	
    public String toString() {
    	return nodeA.toString() + " or " + nodeB.toString();
    }	
    
}
