import java.util.Scanner;

public class Node_Con implements Node_RCon{
    private Node_RCon node = null;
	
	public boolean eval(Robot robot) {
		return node.eval(robot);
	}

	@Override
	public Node_RCon parse(Scanner s) {
		if (s.hasNext(Parser.GREATERTHAN)) {
			node = new Node_Greater();
			node.parse(s);
		} 
		else if (s.hasNext(Parser.LESSTHAN)) {
			node = new Node_Less();
			node.parse(s);
		} 
		else if (s.hasNext(Parser.EQUAL)) {
			node = new Node_Equal();
			node.parse(s);
		}
		else if (s.hasNext(Parser.AND)) {
			node = new Node_And();
			node.parse(s);
		}
		else if (s.hasNext(Parser.NOT)) {
			node = new Node_not();
			node.parse(s);
		}
		else if (s.hasNext(Parser.OR)) {
			node = new Node_Or();
			node.parse(s);
		}
		return node;
	}
	
	public String toString(){
		return node.toString();
	}
    
}
