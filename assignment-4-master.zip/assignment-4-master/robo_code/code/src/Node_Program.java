import java.util.ArrayList;
import java.util.Scanner;

public class Node_Program implements RobotProgramNode {
    private ArrayList<RobotProgramNode> stmts = new ArrayList<>();
    
    /**
     * Add a statement to the program
     */
    @Override
    public void execute(Robot robot) {
        for (RobotProgramNode stmt : stmts) {
            stmt.execute(robot);
        }
    }
    /**
     * Parse a program
     */
    public RobotProgramNode parse(Scanner s){
        Node_STMT stmt = null;
        while(s.hasNext()){
            stmt = new Node_STMT();
            stmts.add(stmt.parse(s));
        }
        return this;
    }
    /**
     * toString method for the program
     */
    public String toString() {
        String s = "";
        for (RobotProgramNode stmt : stmts) {
            s += stmt.toString() + "\n";
        }
        return s;
    }
}
    

