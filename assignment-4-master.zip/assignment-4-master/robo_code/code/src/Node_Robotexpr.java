import java.util.Scanner;

public interface Node_Robotexpr {	
	
	public int eval(Robot robot);
	
	public Node_Robotexpr parse (Scanner s);
	
	public String toString();
}