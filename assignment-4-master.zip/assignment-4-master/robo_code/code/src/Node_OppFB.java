import java.util.Scanner;

public class Node_OppFB implements Node_Robotexpr{

	@Override
	public int eval(Robot robot) {
		return robot.getOpponentFB();
	}

	@Override
	public Node_Robotexpr parse(Scanner s) {
		if(!Parser.checkFor(Parser.OPPFB, s)){
			Parser.fail("Node OpponentFB Fail\n", s);
		}
		return this;
	}
	
	public String toString(){
		return Parser.OPPFB.toString();
	}

}
