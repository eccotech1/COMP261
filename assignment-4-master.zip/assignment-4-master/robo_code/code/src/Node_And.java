import java.util.Scanner;

public class Node_And implements Node_RCon {
    public Node_Con con1 = null;
	public Node_Con con2 = null;

	@Override
	public boolean eval(Robot robot) {
		if(con1.eval(robot) && con2.eval(robot)){
			return true;
		}
		return false;
	}

	@Override
	public Node_RCon parse(Scanner s) {
		if(!Parser.checkFor(Parser.AND, s)){
			Parser.fail("Node And Fail\n", s);
		}
		
		if(!Parser.checkFor(Parser.OPENPAREN, s)){
			Parser.fail("Node And Fail\n", s);
		}
		
		con1 = new Node_Con();
		con1.parse(s);	
		
		if (s.hasNext(Parser.COMMA)) {
			Parser.checkFor(Parser.COMMA, s);
		}
		
		con2 = new Node_Con();
		con2.parse(s);
		
		if (!Parser.checkFor(Parser.CLOSEPAREN, s)) {
			Parser.fail("Node And Fail\n", s);
		}
		
		return this;
	}
	
	@Override
	public String toString(){
		return "and("+con1+", "+con2+")"; 
	}
    
}
