import java.util.Scanner;

public class Node_TakeL implements RobotProgramNode {
    @Override
    public void execute(Robot robot) {
        robot.turnLeft();
    }
    @Override
    public RobotProgramNode parse(Scanner s) {
        if(!Parser.checkFor(Parser.TURNL, s)){
            Parser.fail("Failed Turn Left\n", s);
        }
        return this;
    }

    public String toString() {
        return "turnLeft;";
    }
    
}
