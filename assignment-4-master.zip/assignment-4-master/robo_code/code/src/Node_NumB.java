import java.util.Scanner;

public class Node_NumB implements Node_Robotexpr{

	@Override
	public int eval(Robot robot) {
		return robot.numBarrels();
	}

	@Override
	public Node_Robotexpr parse(Scanner s) {
		if(!Parser.checkFor(Parser.NUMBARRELS, s)){
			Parser.fail("Node NumBarrel Fail\n", s);
		}
		return this;
	}
	
	public String toString() {
		return Parser.NUMBARRELS.toString();
	}
}
