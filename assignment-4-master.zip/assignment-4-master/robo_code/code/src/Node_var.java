import java.util.Scanner;

public class Node_var implements Node_Robotexpr{
    private String name = "";
    private Node_expr expression = null;
    
    public Node_var(String name){
    	this.name = name;
    }

	@Override
	public int eval(Robot robot) {
		return expression.eval(robot);
	}

	@Override
	public Node_Robotexpr parse(Scanner s) {
	    String variableName = s.next();

	    if (Node_expr.map.containsKey(variableName)) {
	    	return new Node_var(variableName);	
	    }

	    if (Node_expr.is_expr) {
	    	Parser.fail("Node Variable Failed\n", s);
	    } else {
	    	Node_expr.map.put(variableName, 0);
	    	return new Node_var(variableName);
	    }  
	    return this;
	}
    public String toString() {
    	return this.name;
    }
}