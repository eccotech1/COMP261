import java.util.Scanner;

public class Node_opers implements Node_Robotexpr {
    Node_Robotexpr opers = null;
    
    @Override
    public int eval(Robot robot){
        return opers.eval(robot);
    }
    @Override
    public Node_Robotexpr parse(Scanner s){
        if (s.hasNext(Parser.ADD)) {      
            opers = new Node_Add();
        } else if (s.hasNext(Parser.SUB)){
            opers = new Node_Sub();
        } else if (s.hasNext(Parser.MUL)){
            opers = new Node_Mul();
        } else if (s.hasNext(Parser.DIV)){
            opers = new Node_Div();
        } 
        opers.parse(s);
        return opers;
    }
    

public String toString(){
    return opers.toString();
}

}
