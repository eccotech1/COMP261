import java.util.Scanner;

public class Node_A implements RobotProgramNode{
	
    private String variableName = "";
    private Node_expr expression = null;
    
	@Override
	public void execute(Robot robot) {
		Node_expr.map.put(this.variableName, this.expression.eval(robot));	
	}

	@Override
	public RobotProgramNode parse(Scanner s) {
		if (s.hasNext(Parser.VARIABLE)) {
			variableName = s.next();
		}

		if(s.hasNext("=")) {
			s.next();
		    expression = new Node_expr();
		    expression.parse(s);
		}
		
		if(s.hasNext(";")) {
			s.next();
		}
		
		return this;
	}
	
	public void setExpression(Node_expr expression){
		this.expression = expression;
	}
	
	public void setName(String name){
		this.variableName = name;
	}
	
    public String toString() {
    	return variableName.toString() + " = "+ expression.toString();
    }
}