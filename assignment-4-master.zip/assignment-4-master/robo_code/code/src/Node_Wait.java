import java.util.Scanner;

public class Node_Wait implements RobotProgramNode{
    private Node_expr expr = null;
    @Override
	public void execute(Robot robot) {
		robot.idleWait();		
	}

	@Override
	public RobotProgramNode parse(Scanner s) {
		if (!Parser.checkFor(Parser.WAIT, s)) {
			Parser.fail("Wait Fail \n", s);
		}
		
		if (s.hasNext(Parser.OPENPAREN)) {
			Parser.checkFor(Parser.OPENPAREN, s);	
		}
		
		if (s.hasNext(Parser.SENSOR) || s.hasNext(Parser.NUMPAT) ||
				s.hasNext(Parser.OPERATION)) {
			expr = new Node_expr();
			expr.parse(s);
		}
		
		if (s.hasNext(Parser.CLOSEPAREN)) {
			Parser.checkFor(Parser.CLOSEPAREN, s);
		}	
	
		return this;
	}
	
	public String toString(){
		if (expr == null) {
			return ("wait;");
		}
		else {
			return "wait (" + expr.toString() + ");";
		}
	}
    
}
