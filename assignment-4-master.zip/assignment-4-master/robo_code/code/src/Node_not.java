import java.util.Scanner;

public class Node_not implements Node_RCon{
    Node_Con node = null;
	
	@Override
	public boolean eval(Robot robot) {
		return false;
	}

	@Override
	public Node_RCon parse(Scanner s) {
		if(!Parser.checkFor(Parser.NOT, s)){
			Parser.fail("Node Not failed \n", s);
		}
		
		if (!Parser.checkFor(Parser.OPENPAREN, s)) {
			Parser.fail("Node Not failed" + Parser.OPENPAREN.toString(), s);
		}

		node = new Node_Con();
		node.parse(s);

		if (!Parser.checkFor(Parser.CLOSEPAREN, s)) {
			Parser.fail("Node Not failed"+ Parser.CLOSEPAREN.toString(), s);
		}
		return this;
	}
	
	public String toString() {
		return "not("+node.toString()+")";
	}
    
}
