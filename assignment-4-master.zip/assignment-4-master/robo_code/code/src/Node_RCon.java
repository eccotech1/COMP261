import java.util.Scanner;

public interface Node_RCon {

	public boolean eval(Robot robot);

	public Node_RCon parse(Scanner scan);
	
	public String toString();
		
}