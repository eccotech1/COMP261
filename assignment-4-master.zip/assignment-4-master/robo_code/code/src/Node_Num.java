import java.util.Scanner;

public class Node_Num implements Node_Robotexpr {
    private int number = 0;
	
	@Override
	public int eval(Robot robot) {
		return number;
	}

	@Override
	public Node_Robotexpr parse(Scanner s) {
		number = Parser.requireInt(Parser.NUMPAT, "NUMNode Fail, not a number.", s);
        return this;
	}
	
	public String toString() {
		return Integer.toString(number);
	}

    
}
