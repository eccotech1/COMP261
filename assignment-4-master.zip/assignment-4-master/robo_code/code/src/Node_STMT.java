import java.util.Scanner;

public class Node_STMT implements RobotProgramNode{
    private RobotProgramNode stmt = null;
    /**
     * add a statement to the program
     */
    @Override
    public void execute(Robot robot) {
        stmt.execute(robot);
    }
     /**
     * Parse a statement
     */
    @Override
    public RobotProgramNode parse(Scanner s){
        if(s.hasNext(Parser.ACTION)){
            stmt = new Node_Action();
        }else if(s.hasNext(Parser.LOOP)){
            stmt = new Node_Loop();
         }else if(s.hasNext(Parser.IF)){
            stmt = new Node_If();
        }else if(s.hasNext(Parser.WHILE)){
            stmt = new Node_While();
        }else if (s.hasNext(Parser.VARIABLE)) {
			stmt = new Node_A();
		}
        else{
            Parser.fail("Failed Statement", s);
        }
        stmt.parse(s);
        return this;
        
    }
    /**
     * toString method for the statement
     */
    public String toString(){
        return stmt.toString();
    }
}
        