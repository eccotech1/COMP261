import java.util.Scanner;

public class Node_Mul implements Node_Robotexpr{

    private Node_expr n1 = null;
    private Node_expr n2 = null;

    private int num1 = -1;
    private int num2 = -1;

    @Override
    public int eval(Robot robot){
        num1 = n1.eval(robot);
        num2 = n2.eval(robot);

        return (num1 * num2);
    }

    @Override
    public Node_Robotexpr parse(Scanner s){
		if (!Parser.checkFor(Parser.MUL, s)) {
            Parser.fail("Node Multiply Fail\n ", s);		
		}

		if (!Parser.checkFor(Parser.OPENPAREN, s)) {
            Parser.fail("Node Multiply Fail\n ", s);		
        }
	
		n1 = new Node_expr();
		n1.parse(s);
	
		if (!Parser.checkFor(Parser.COMMA, s)) {
            Parser.fail("Node Multiply Fail\n ", s);		
        }
	
		n2 = new Node_expr();
		n2.parse(s);
	
		if (!Parser.checkFor(Parser.CLOSEPAREN, s)) {
            Parser.fail("Node Multiply Fail\n ", s);		
        }
		return this;
        }

        public String toString(){
            return String.format("mul(%s, %s)", n1.toString(), n2.toString());

        }
        
    }
    

