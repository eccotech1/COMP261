import java.util.ArrayList;
import java.util.Scanner;

public class Node_Block implements RobotProgramNode {
    public ArrayList<RobotProgramNode> blocks = new ArrayList<>();

    public void execute(Robot robot) {
        for (RobotProgramNode block : blocks) {
            block.execute(robot);
        }
    }

    @Override
    public RobotProgramNode parse(Scanner s) {
        RobotProgramNode block = null;
            if(!Parser.checkFor(Parser.OPENBRACE, s)){
                Parser.fail("Node Block\n" + block, s);
            }

            if(s.hasNext()){
                block = new Node_STMT();
                blocks.add(block.parse(s));
            }
            while(!s.hasNext(Parser.CLOSEBRACE)){
                if(s.hasNext()){
                    block = new Node_STMT();
                    blocks.add(block.parse(s));
                }
            }
            if(!Parser.checkFor(Parser.CLOSEBRACE, s)){
                Parser.fail("Close Bracket fail", s);
            }
        return this;
    }
    public String toString(){
        String s = "{\n";
        
        for (RobotProgramNode block : blocks) {
            if(!block.toString().equals("}")){
                s += "     "+block.toString() + "\n";
            }
            
        }
        return s + "}";
    }
}
