import java.util.*;
import java.io.*;

public class LempelZivCompress {

    public static void main(String[] args) {
        if (args.length != 1) {
            System.out.println("Please call this program with one argument which is the input file name.");
        } else {
            try {
                Scanner s = new Scanner(new File(args[0]));

                // Read the entire file into one String.
                StringBuilder fileText = new StringBuilder();
                while (s.hasNextLine()) {
                    fileText.append(s.nextLine() + "\n");
                }

                System.out.println(compress(fileText.toString()));
            } catch (FileNotFoundException e) {
                System.out.println("Unable to find file called " + args[0]);
            }
        }
    }
    
    /**
     * Take uncompressed input as a text string, compress it, and return it as a
     * text string.
     */
    public static String compress(String input) {
		ArrayList<TupleNode> output = new ArrayList<>(); // we will compress the text into this array of tuple nodes
        StringBuilder cPressed = new StringBuilder(); // this will hold the compressed string
		int point = 0;
		int wSize = 100; // some suitable size
		int buff = 0; // look ahead buffer
		while (point < input.length()) {
			buff = (point + buff >= input.length()) ? input.length() : point + buff; // check if we are at the end of the string
			int sbStart = (point - wSize < 0) ? 0 : point - wSize; // check if we are at the start of the string
			int foundLen = 1; // length of the same string
			int foundLoc = 0;// location of the same string
			String s = (point == 0) ? "" : input.substring(sbStart, point); // get the substring of the string
			String nextString = input.substring(point, point + foundLen);
			char nextChar = input.charAt(point);
			int offset = 0;
			if (s.contains(nextString)) { // check if the next string is in the string buffer
				for (int i = point - 1; i >= sbStart; i--) { // find the position of the very last occurance of this
					if (input.charAt(i) == nextChar) {
						foundLoc = i;
						offset = point - foundLoc;
						break;
					}
				}
				int len = 1; // the length of the match we have found so far is 1, now we look further on
				for (int i = foundLoc + 1; i < point; i++) {
					if (point + len >= input.length()) {
						break;
					}
					char n = input.charAt(point + len);
					if (input.charAt(i) == n) { // if the next char is the same as the next char in the search buffer												
							len++;
					} else {
						break; // if the next char is not the same, we have found the end of the match
					}
				}
				if (point + len < input.length()) {
					point = point + len;
				}
				output.add(new TupleNode(offset, len, input.charAt(point)));
			} else {
				char character = input.charAt(point);
				output.add(new TupleNode(0, 0, character)); // if the pattern does not match then we add a new tuple node with the character at the current point													 
			}
			point++;
		}
		for (TupleNode t : output) {
			cPressed.append(t.toString());
		}
		return cPressed.toString();
    }
}
