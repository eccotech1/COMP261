import java.util.*;
import java.io.*;

/**
* A new instance of HuffmanCoding is created for every run. The constructor is
* passed the full text to be encoded or decoded, so this is a good place to
* construct the tree. You should store this tree in a field and then use it in
* the encode and decode methods.
*/
public class HuffmanCoding {
    
    public static void main(String[] args) {
        if (args.length != 2) {
            System.out.println("Please call this program with two arguments, which are " +
            "the input file name and either 0 for constructing tree and printing it, or " +
            "1 for constructing the tree and encoding the file and printing it, or " +
            "2 for constructing the tree, encoding the file, and then decoding it and " +
            "printing the result which should be the same as the input file.");
        } else {
            try {
                Scanner s = new Scanner(new File(args[0]));
                
                // Read the entire file into one String.
                StringBuilder fileText = new StringBuilder();
                while (s.hasNextLine()) {
                    fileText.append(s.nextLine() + "\n");
                }
                
                if (args[1].equals("0")) {
                    System.out.println(constructTree(fileText.toString()));
                } else if (args[1].equals("1")) {
                    constructTree(fileText.toString()); // initialises the tree field.
                    System.out.println(encode(fileText.toString()));
                } else if (args[1].equals("2")) {
                    constructTree(fileText.toString()); // initialises the tree field.
                    String codedText = encode(fileText.toString());
                    // DO NOT just change this code to simply print fileText.toString() back. ;-)
                    System.out.println(decode(codedText));
                } else {
                    System.out.println("Unknown second argument: should be 0 or 1 or 2");
                }
            } catch (FileNotFoundException e) {
                System.out.println("Unable to find file called " + args[0]);
            }
        }
    }
    
    // TODO add a field with your ACTUAL HuffmanTree implementation.
    private static HashMap<Character, String> in = new HashMap<>();
    private static HashMap<HuffmanHelper, String> out = new HashMap<>();
    private static HuffmanHelper tree; // the tree we will use to encode and decode.
    
    /**
    * This would be a good place to compute and store the tree.
    */
    public static Map<Character, String> constructTree(String text) {
        PriorityQueue<HuffmanHelper> prioQueue = freqQueue(text); // priority queue of node and its count
        while (prioQueue.size() > 1) {
            HuffmanHelper first = prioQueue.poll(); // first node in the queue
            HuffmanHelper next = prioQueue.poll(); // second node in the queue
            int sumCount = first.getFreq() + next.getFreq();
            char nextChar = next.getCharacter().charAt(0);
            char rootChar = first.getCharacter().charAt(0);
            HuffmanHelper outNode = null;
            if (Character.compare(nextChar, rootChar) < 0) { // if the next node is smaller than the root node
                // create a new node with the root and next node
                outNode = new HuffmanHelper(next.getCharacter(), sumCount, first, next, true);
            } else {
                // create a new node with the next node and root node
                outNode = new HuffmanHelper(first.getCharacter(), sumCount, first, next, true);
            }
            prioQueue.add(outNode); // add the new node to the queue
        }
        // the tree is now constructed
        HuffmanHelper root = prioQueue.poll(); // get the root node
        tree = root; // set the tree to the root node
        out.put(root, ""); // add the root node to the map
        traverseTree(root); // traverse the tree to add the rest of the nodes to the map
        in = extract(); // extract the node from the map
        return in; // return the map

    }
    
    /**
    * Take an input string, text, and encode it with the tree computed from the text. Should
    * return the encoded text as a binary string, that is, a string containing
    * only 1 and 0.
    */
    public static String encode(String text) {
        // TODO fill this in.
		String eString = ""; // encoded string
        // traverse the tree to get the encoded string
		for (int i = 0; i < text.length(); i++) {
			char c = text.charAt(i); // get the character
			String binString = in.get(c); // get the binary string
			eString += binString; // add the binary string to the encoded string
		}
		return eString; // return the encoded string
    }
    
    /**
    * Take encoded input as a binary string, decode it using the stored tree,
    * and return the decoded text as a text string.
    */
    public static String decode(String encoded) {
		String decoString = "";
		HuffmanHelper root = tree; 
		for (int i = 0; i < encoded.length(); i++) { // traverse the encoded string
			char binCost = encoded.charAt(i); // get the character
			if (binCost == '0') { // if the character is 0
				HuffmanHelper first = root.leftChild(); // get the left child
				if (!first.combined()) { // node is a node containing a char not a combined node
					root = tree; // reset back to rootNode
					decoString += first.getCharacter(); // add the char to the decoded string
				}
				else {
                    
					root = first; //set the root to the left child
				}
			}
			if (binCost == '1') { //if the character is 1
				HuffmanHelper next = root.rightChild();
				if (!next.combined()) { // node's character not null but a char
                root = tree; // reset back to rootNode
					decoString = decoString + next.getCharacter();
				}
				else {
					root = next; // setting startNode to rightNode for further traverse
				}
			}
		}
		return decoString;
    }
    /**
     * Traverse the tree to add the rest of the nodes to the map
     * @param node
     */
    public static void traverseTree(HuffmanHelper node) {
		String txt = out.get(node);
		HuffmanHelper first = node.leftChild();
		HuffmanHelper next = node.rightChild();
		if (first != null) {
			out.put(first, txt + "0");
			traverseTree(first);
		}
		if (next != null) {
			out.put(next, txt + "1");
			traverseTree(next);
		}
	}
    /**
     * freqQueue takes a string and returns a priority queue of HuffmanHelper nodes
     * @param text
     * @return
     */
    public static PriorityQueue<HuffmanHelper> freqQueue(String text) {
		Map<Character, Integer> freqTable = new HashMap<>(); // frequency table
        PriorityQueue<HuffmanHelper> prioNode = new PriorityQueue<>(); // priority queue of node and its count
		for (int i = 0; i < text.length(); i++) { // traverse the text
			Character c = text.charAt(i); // get the character
			if (!freqTable.keySet().contains(c)) { // if the character is not in the table
				freqTable.put(c, 1); // add the character to the table with count 1
			} else { // if the character is in the table
				int freq = freqTable.get(c);
				freqTable.put(c, freq + 1);
			}
		}
		for (Character c : freqTable.keySet()) { // traverse the table
			String ch = "" + c;
			int freq = freqTable.get(c);
			HuffmanHelper n = new HuffmanHelper(ch, freq, null, null, false);
			prioNode.add(n); // add the node to the priority queue
		}
		return prioNode;
	}
    /**
     * extractNode takes the map and returns a map of HuffmanHelper nodes
     * @return
     */
	public static HashMap<Character, String> extract() {
		HashMap<Character, String> extracted = new HashMap<>(); // extracted map
		for (HuffmanHelper node : out.keySet()) {// traverse the map
			if (!node.combined()) {
                char c = node.getCharacter().charAt(0);
				extracted.put(c, out.get(node));
			}
		}
		return extracted;
	}
}
