public class TupleNode {
	int oSet; 
	int len;
	char c;
	public TupleNode(int oSet, int len, char c) {
		this.oSet = oSet;
		this.len = len;
		this.c = c;
	}
	@Override
	public String toString() {
		return "[" + oSet + "|" + len + "|" + c + "]";		
	}
}