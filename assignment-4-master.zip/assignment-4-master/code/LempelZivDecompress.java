import java.util.*;
import java.io.*;

public class LempelZivDecompress {
    
    public static void main(String[] args) {
        if (args.length != 1) {
            System.out.println("Please call this program with one argument which is the input file name.");
        } else {
            try {
                Scanner s = new Scanner(new File(args[0]));
                
                // Read the entire file into one String.
                StringBuilder fileText = new StringBuilder();
                while (s.hasNextLine()) {
                    fileText.append(s.nextLine() + "\n");
                }
                
                System.out.println(decompress(fileText.toString()));
            } catch (FileNotFoundException e) {
                System.out.println("Unable to find file called " + args[0]);
            }
        }
    }
    
    /**
    * Take compressed input as a text string, decompress it, and return it as a
    * text string.
    */
    public static String decompress(String compressed) {
        char cChar[] = compressed.toCharArray(); // convert the compressed string into an array of characters
        ArrayList<TupleNode> dcompressed = new ArrayList<TupleNode>(); // we will decompress the compressed array of tuple nodes into this array of tuple nodes
        StringBuilder oSet = new StringBuilder(); // this will hold the offset value
        StringBuilder length = new StringBuilder(); // this will hold the length value
        int caseNum = 0; // 1 = offset, 2 = length, 3 = character then reset to 0
        for(char c : cChar) {
            if(c != '[' && c != ']' && c != '|') {
                if(caseNum == 1) {
                    oSet.append(c); // append the character to the offset value
                }
                else if(caseNum == 2) {					
                    length.append(c); // add the character to the length string
                }
                else if(caseNum == 3) {					
                    int offS = Integer.parseInt(oSet.toString()); // convert the offset value to an integer
                    int len = Integer.parseInt(length.toString()); // convert the offset and length values into integers
                    TupleNode incNode = new TupleNode(offS, len, c); // create a new tuple node with the offset, length, and character
                    dcompressed.add(incNode);// add the tuple node to the array list of tuple nodes
                    //reset
                    oSet = new StringBuilder(); 
                    length = new StringBuilder(); 					
                    caseNum = -1; 
                }
            }
            else {
                caseNum++; //increment case number
            }
        }
        StringBuilder s = new StringBuilder();		
        ArrayList<Character> output = new ArrayList<Character>();		
        int point = 0;
        int numdCompressed = 0;
        for(TupleNode t : dcompressed) { // for each tuple node in the array list of tuple nodes
            if(t.len == 0) { //if length is 0, then we have a character to add to ouput
                output.add(point++, t.c);
            } 
            else { //if the length is not 0, we add the char to the output and then add the next char to the output
                for (int j = 0; j< t.len; j++) {
                    output.add(output.get(point-t.oSet));
                    point++;
                }
                if(numdCompressed<dcompressed.size()-1) {
                    output.add(point++, t.c); //add the character after the word
                }				
            }
            numdCompressed++;
        }	
        for(char c : output) {
            s.append(c);
        }
        return s.toString();	
    }
}

