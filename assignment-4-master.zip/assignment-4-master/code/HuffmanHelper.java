public class HuffmanHelper implements Comparable<HuffmanHelper>{
	private String c;
	private int count;
	private HuffmanHelper n1;
	private HuffmanHelper n2;
	private boolean done;
	
	public HuffmanHelper(String c, int count, HuffmanHelper n1, HuffmanHelper n2, boolean done) {
		this.c = c;
		this.count = count;
		this.n1 = n1;
		this.n2 = n2;
		this.done = done;
	}

	@Override
	public int compareTo(HuffmanHelper o) {
		
		if(this.count < o.count) { //less count more priority
			return -1;
		}else if(this.count > o.count) { //more count less priority
			return 1;
		}else {
			//equal count
			if(Character.compare(this.c.charAt(0), o.c.charAt(0))<0) { 
				return -1;
			}else {
				return 1;
			}
		}		
	}
	//getters and setters
	public String getCharacter() {
		return c;
	}
	
	public int getFreq() {
		return count;
	}
	
	public HuffmanHelper leftChild() {
		return n1;
	}
	
	public HuffmanHelper rightChild() {
		return n2;
	}
	
	public boolean combined() {
		return done;
	}
	
	
}